Sustentabilidade é a Esperança-Agrinho 2026
-------------------------------------------
Este jogo vc utiliza seta pra direita e seta pra esquerda, pegue o máximo dee plantas possíveis e fuja das indústrias de ultra processados .

Foi utilizado o aplicativo Gemini para me auxiliar com os códigos.

A [Pen](https://codepen.io/CAMILLA-OLIVEIRA-SCOTTI/pen/bNgwaZJ) by [CAMILLA OLIVEIRA SCOTTI](https://codepen.io/CAMILLA-OLIVEIRA-SCOTTI) on [CodePen](https://codepen.io).

[License](https://codepen.io/license/pen/bNgwaZJ).