function calcularEconomia() {
    // Pega os hectares digitados pelo usuário
    const hectaresInput = document.getElementById('hectares');
    const hectares = parseFloat(hectaresInput.value);

    // Validação de entrada do usuário
    if (isNaN(hectares) || hectares <= 0) {
        alert("Por favor, digite uma quantidade válida de hectares para calcular.");
        return;
    }

    // Cálculos estimados para plantações:
    // Média de economia de 1.500.000 litros de água por hectare/ano com gotejamento vs aspersão comum
    const litrosEconomizados = (hectares * 1500000).toLocaleString('pt-BR');
    
    // Estimativa de controle de erosão (valor fixo referencial de melhoria)
    const reducaoErosao = 45; 

    // Atualiza os valores na tela
    document.getElementById('agua').innerText = litrosEconomizados;
    document.getElementById('solo').innerText = reducaoErosao;

    // Mostra o quadro de resultados mudando a propriedade de exibição
    const resultadoDiv = document.getElementById('resultado');
    resultadoDiv.style.display = 'block';
}